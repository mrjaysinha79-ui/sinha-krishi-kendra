(function () {
'use strict';

/* ============ दुकान की जानकारी / Shop info ============ */
var SHOP = {
  name: 'सिन्हा कृषि केंद्र',
  nameEn: 'Sinha Krishi Kendra',
  phone: '8103584657',
  wa: '918103584657',
  addr: 'Avasplatpara, Talnar, Bastar, Chhattisgarh, India'
};

var CATS = [
  { id: 'seeds',      hi: 'बीज',          en: 'Seeds',        icon: '🌱' },
  { id: 'fertilizer', hi: 'खाद',          en: 'Fertilizers',  icon: '🧪' },
  { id: 'pesticide',  hi: 'कीटनाशक',      en: 'Pesticides',   icon: '🐛' },
  { id: 'tools',      hi: 'कृषि औज़ार',   en: 'Farming Tools', icon: '⛏️' }
];

/* ============ Saving / Loading ============ */
/* Inside the Android app data is saved as files (NativeStore). In a normal browser it uses localStorage. */
var store = {
  get: function (k) {
    try {
      var s;
      if (window.NativeStore) { s = window.NativeStore.loadData(k); }
      else { s = localStorage.getItem('skk_' + k); }
      return s ? JSON.parse(s) : null;
    } catch (e) { return null; }
  },
  set: function (k, v) {
    try {
      var s = JSON.stringify(v);
      if (window.NativeStore) { return !!window.NativeStore.saveData(k, s); }
      localStorage.setItem('skk_' + k, s);
      return true;
    } catch (e) { return false; }
  }
};

/* ============ Helpers ============ */
function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}
function money(n) {
  n = Number(n) || 0;
  var r = Math.round(n * 100) / 100;
  var s;
  try { s = r.toLocaleString('en-IN', { maximumFractionDigits: 2 }); } catch (e) { s = String(r); }
  return '₹' + s;
}
function $(id) { return document.getElementById(id); }
function catOf(id) { for (var i = 0; i < CATS.length; i++) { if (CATS[i].id === id) return CATS[i]; } return CATS[0]; }
function findP(id) { for (var i = 0; i < products.length; i++) { if (products[i].id === id) return products[i]; } return null; }
function openUrl(u) { window.__lastUrl = u; location.href = u; }

var toastTimer = null;
function toast(msg) {
  var t = $('toast');
  t.textContent = msg; t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(function () { t.hidden = true; }, 2200);
}

/* ============ Demo data (नमूना डेटा) — clearly labelled, prices are NOT real ============ */
function demoImg(emoji, bg) {
  var svg = '<svg xmlns="http://www.w3.org/2000/svg" width="300" height="300"><rect width="300" height="300" fill="' + bg +
    '"/><text x="150" y="190" font-size="130" text-anchor="middle">' + emoji + '</text></svg>';
  return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
}
function demoProducts() {
  var d = [
    ['धान बीज', 'Paddy Seed', 'seeds', 100, '1 kg', 50, '🌾', '#FFF3C4'],
    ['मक्का बीज', 'Maize Seed', 'seeds', 150, '1 kg', 30, '🌽', '#FFE9A8'],
    ['सब्ज़ी बीज पैकेट', 'Vegetable Seed Pack', 'seeds', 20, '1 पैकेट', 100, '🥬', '#D7F0D2'],
    ['यूरिया खाद', 'Urea', 'fertilizer', 300, '45 kg', 20, '🧴', '#E3F2FD'],
    ['DAP खाद', 'DAP', 'fertilizer', 1000, '50 kg', 4, '🧪', '#EDE7F6'],
    ['जैविक खाद', 'Organic Compost', 'fertilizer', 100, '5 kg', 40, '🍂', '#EFEBE9'],
    ['कीटनाशक', 'Insecticide', 'pesticide', 250, '500 ml', 15, '🐛', '#FDE7E7'],
    ['फफूंदनाशक', 'Fungicide', 'pesticide', 200, '250 g', 12, '🍄', '#F3E5F5'],
    ['खरपतवारनाशक', 'Weedicide', 'pesticide', 400, '1 L', 0, '🌿', '#E0F2F1'],
    ['खुरपी', 'Hand Hoe', 'tools', 120, '1 नग', 25, '⛏️', '#ECEFF1'],
    ['हँसिया', 'Sickle', 'tools', 150, '1 नग', 18, '🔪', '#FFF8E1'],
    ['स्प्रे पंप', 'Sprayer', 'tools', 1500, '16 L', 5, '💦', '#E1F5FE']
  ];
  return d.map(function (x, i) {
    return { id: 'demo' + (i + 1), name: x[0], nameEn: x[1], cat: x[2], price: x[3], unit: x[4],
      stock: x[5], img: demoImg(x[6], x[7]), demo: true };
  });
}

/* ============ State ============ */
var settings = store.get('settings') || { pin: '1234' };
var products = store.get('products');
if (!Array.isArray(products)) { products = demoProducts(); store.set('products', products); }
var cart = store.get('cart');
if (!Array.isArray(cart)) { cart = []; }
var customer = store.get('customer') || { name: '', phone: '', addr: '' };
var ui = { cat: 'all', q: '', admin: false, form: null };

function saveProducts() { if (!store.set('products', products)) { toast('⚠️ सेव नहीं हो सका!'); return false; } return true; }
function saveCart() { store.set('cart', cart); updateBadge(); }

/* ============ Cart ============ */
function cartQty(id) { for (var i = 0; i < cart.length; i++) { if (cart[i].id === id) return cart[i].qty; } return 0; }
function setQty(id, q) {
  var p = findP(id);
  if (!p) { q = 0; }
  else if (q > p.stock) { q = p.stock; toast('इतना ही स्टॉक है (' + p.stock + ')'); }
  var found = false;
  cart = cart.filter(function (c) {
    if (c.id === id) { found = true; c.qty = q; return q > 0; }
    return true;
  });
  if (!found && q > 0) { cart.push({ id: id, qty: q }); }
  saveCart();
}
function sanitizeCart() {
  var changed = false;
  cart = cart.filter(function (c) {
    var p = findP(c.id);
    if (!p || p.stock <= 0) { changed = true; return false; }
    if (c.qty > p.stock) { c.qty = p.stock; changed = true; }
    if (c.qty < 1) { changed = true; return false; }
    return true;
  });
  if (changed) { saveCart(); }
  return changed;
}
function cartItems() {
  return cart.map(function (c) { return { p: findP(c.id), qty: c.qty }; }).filter(function (x) { return x.p; });
}
function cartTotal() {
  return cartItems().reduce(function (s, x) { return s + x.p.price * x.qty; }, 0);
}
function cartCount() { return cart.reduce(function (s, c) { return s + c.qty; }, 0); }
function updateBadge() {
  var b = $('cartBadge'), n = cartCount();
  b.textContent = n; b.hidden = n === 0;
}

/* ============ WhatsApp message ============ */
function buildMessage(cust, items, total) {
  var L = [];
  L.push('🌿 *नया ऑर्डर - ' + SHOP.name + '*');
  L.push('');
  L.push('👤 *ग्राहक / Customer:* ' + cust.name);
  if (cust.phone) { L.push('📞 *फ़ोन / Phone:* ' + cust.phone); }
  if (cust.addr) { L.push('📍 *पता / Address:* ' + cust.addr); }
  L.push('');
  L.push('🛒 *ऑर्डर / Order:*');
  items.forEach(function (x, i) {
    var p = x.p;
    L.push((i + 1) + '. ' + p.name + (p.nameEn ? ' (' + p.nameEn + ')' : '') + (p.unit ? ' [' + p.unit + ']' : '') +
      ' - ' + x.qty + ' × ' + money(p.price) + ' = ' + money(p.price * x.qty) + (p.demo ? ' [डेमो]' : ''));
  });
  L.push('');
  L.push('💰 *कुल / Total: ' + money(total) + '*');
  if (cust.note) { L.push(''); L.push('📝 ' + cust.note); }
  L.push('');
  L.push('कृपया ऑर्डर कन्फ़र्म करें। 🙏');
  return L.join('\n');
}
function waLink(text) { return 'https://wa.me/' + SHOP.wa + '?text=' + encodeURIComponent(text); }

/* ============ Modal ============ */
function closeModal() { $('modalRoot').innerHTML = ''; }
function modalOpen() { return $('modalRoot').innerHTML !== ''; }
function showModal(html) {
  $('modalRoot').innerHTML = '<div class="ov"><div class="box">' + html + '</div></div>';
}
var modalYes = null;
function confirmBox(msg, yesLabel, onYes, noLabel) {
  modalYes = onYes;
  showModal('<p style="margin-top:0;font-size:17px">' + msg + '</p>' +
    '<button class="btn red" data-act="modalyes">' + esc(yesLabel) + '</button>' +
    '<button class="btn sec" data-act="modalno">' + esc(noLabel || 'नहीं / Cancel') + '</button>');
}

/* ============ Views ============ */
var V = $('view');

function stockHtml(p) {
  if (p.stock <= 0) { return '<span class="stock-out">स्टॉक खत्म / Out of stock</span>'; }
  if (p.stock <= 5) { return '<span class="stock-low">सिर्फ़ ' + p.stock + ' बचे / Only ' + p.stock + ' left</span>'; }
  return '<span class="stock-ok">स्टॉक: ' + p.stock + ' उपलब्ध</span>';
}
function imgOf(p) { return p.img || demoImg('🌱', '#E8F5E9'); }

function viewHome() {
  var hasDemo = products.some(function (p) { return p.demo; });
  var chips = '<button class="chip' + (ui.cat === 'all' ? ' on' : '') + '" data-act="cat" data-cat="all">सभी / All</button>' +
    CATS.map(function (c) {
      return '<button class="chip' + (ui.cat === c.id ? ' on' : '') + '" data-act="cat" data-cat="' + c.id + '">' +
        c.icon + ' ' + c.hi + ' <small>' + c.en + '</small></button>';
    }).join('');
  V.innerHTML =
    (hasDemo ? '<div class="demo-banner">⚠️ <b>डेमो डेटा:</b> अभी दिख रहे कुछ उत्पाद सिर्फ़ <b>नमूना (DEMO)</b> हैं — इनके दाम और स्टॉक असली नहीं हैं। एडमिन में जाकर असली उत्पाद डालें।</div>' : '') +
    '<input id="q" class="search" type="text" placeholder="🔍 खोजें: बीज, खाद, दवा… (Search)" value="' + esc(ui.q) + '">' +
    '<div class="chips">' + chips + '</div>' +
    '<div id="plist"></div>';
  renderList();
}

function renderList() {
  var q = ui.q.trim().toLowerCase();
  var list = products.filter(function (p) {
    if (ui.cat !== 'all' && p.cat !== ui.cat) { return false; }
    if (!q) { return true; }
    return (p.name + ' ' + (p.nameEn || '') + ' ' + catOf(p.cat).hi + ' ' + catOf(p.cat).en).toLowerCase().indexOf(q) >= 0;
  });
  var el = $('plist');
  if (!el) { return; }
  if (!list.length) {
    el.innerHTML = '<div class="empty">😕 कोई उत्पाद नहीं मिला<br><small>No products found</small></div>';
    return;
  }
  el.innerHTML = '<div class="grid">' + list.map(function (p) {
    var n = cartQty(p.id);
    var action;
    if (p.stock <= 0) { action = '<button class="btn add" disabled>स्टॉक खत्म</button>'; }
    else if (n > 0) {
      action = '<div class="stepper"><button data-act="dec" data-id="' + esc(p.id) + '" aria-label="कम">−</button><span>' + n +
        '</span><button data-act="inc" data-id="' + esc(p.id) + '" aria-label="ज़्यादा">+</button></div>';
    } else { action = '<button class="btn add" data-act="add" data-id="' + esc(p.id) + '">🛒 कार्ट में डालें</button>'; }
    return '<div class="card"><div class="ph"><img alt="" src="' + esc(imgOf(p)) + '">' +
      (p.demo ? '<span class="tag-demo">डेमो / DEMO</span>' : '') + '</div><div class="bd">' +
      '<div class="pname">' + esc(p.name) + '</div>' +
      (p.nameEn ? '<div class="pen">' + esc(p.nameEn) + '</div>' : '') +
      '<div class="price">' + money(p.price) + (p.unit ? ' <small>/ ' + esc(p.unit) + '</small>' : '') + '</div>' +
      stockHtml(p) + action + '</div></div>';
  }).join('') + '</div>';
}

function viewCart() {
  sanitizeCart();
  var items = cartItems();
  if (!items.length) {
    V.innerHTML = '<h2>🛒 मेरा कार्ट <small class="small">My Cart</small></h2>' +
      '<div class="empty">कार्ट खाली है<br><small>Your cart is empty</small></div>' +
      '<a class="btn" href="#/">🌱 सामान देखें</a>';
    return;
  }
  V.innerHTML = '<h2>🛒 मेरा कार्ट <small class="small">My Cart</small></h2>' +
    items.map(function (x) {
      var p = x.p;
      return '<div class="row"><img alt="" src="' + esc(imgOf(p)) + '"><div class="mid">' +
        '<div class="pname">' + esc(p.name) + '</div>' +
        '<div class="small">' + money(p.price) + (p.unit ? ' / ' + esc(p.unit) : '') + (p.demo ? ' • डेमो' : '') + '</div>' +
        '<div class="stepper" style="margin-top:6px;max-width:150px"><button data-act="dec" data-id="' + esc(p.id) + '">−</button><span>' + x.qty +
        '</span><button data-act="inc" data-id="' + esc(p.id) + '">+</button></div></div>' +
        '<div class="rt"><div class="price">' + money(p.price * x.qty) + '</div>' +
        '<button class="btn sm sec" style="margin-top:8px" data-act="rm" data-id="' + esc(p.id) + '">🗑️</button></div></div>';
    }).join('') +
    '<div class="total"><span>कुल / Total</span><span>' + money(cartTotal()) + '</span></div>' +
    '<a class="btn" href="#/checkout">✅ आगे बढ़ें / Checkout</a>' +
    '<button class="btn sec" data-act="clearcart">कार्ट खाली करें</button>';
}

function viewCheckout() {
  sanitizeCart();
  var items = cartItems();
  if (!items.length) { location.hash = '#/cart'; return; }
  V.innerHTML = '<h2>📝 ऑर्डर भेजें <small class="small">Checkout</small></h2>' +
    '<div class="panel green">' + items.map(function (x) {
      return '<div class="line"><div style="flex:1">' + esc(x.p.name) + ' × ' + x.qty + '</div><b>' + money(x.p.price * x.qty) + '</b></div>';
    }).join('') + '<div class="total" style="padding:8px 0 0"><span>कुल / Total</span><span>' + money(cartTotal()) + '</span></div></div>' +
    '<label class="f" for="c_name">आपका नाम / Your name *</label>' +
    '<input id="c_name" type="text" autocomplete="name" value="' + esc(customer.name) + '" placeholder="जैसे: रामलाल">' +
    '<label class="f" for="c_phone">फ़ोन नंबर / Phone (ज़रूरी नहीं)</label>' +
    '<input id="c_phone" type="tel" value="' + esc(customer.phone) + '" placeholder="10 अंक">' +
    '<label class="f" for="c_addr">गाँव / पता / Address (ज़रूरी नहीं)</label>' +
    '<input id="c_addr" type="text" value="' + esc(customer.addr) + '">' +
    '<label class="f" for="c_note">संदेश / Note (ज़रूरी नहीं)</label>' +
    '<textarea id="c_note"></textarea>' +
    '<button class="btn wa" data-act="sendwa">💬 WhatsApp पर ऑर्डर भेजें</button>' +
    '<p class="small">इससे WhatsApp खुलेगा और पूरा ऑर्डर लिखा हुआ मिलेगा। आपको बस "Send" दबाना है। दाम और स्टॉक की पुष्टि दुकान से होगी।</p>';
}

function viewShop() {
  var mapQ = encodeURIComponent(SHOP.addr);
  var hello = 'नमस्ते ' + SHOP.name + ', मुझे जानकारी चाहिए।';
  V.innerHTML = '<h2>🏪 ' + esc(SHOP.name) + ' <small class="small">' + esc(SHOP.nameEn) + '</small></h2>' +
    '<div class="panel green"><h3>📍 पता / Address</h3><div>' + esc(SHOP.addr) + '</div></div>' +
    '<div class="panel"><h3>📞 मोबाइल / WhatsApp</h3><div style="font-size:20px;font-weight:800">' + SHOP.phone + '</div></div>' +
    '<a class="btn" href="tel:' + SHOP.phone + '">📞 दुकान को कॉल करें / Call Shop</a>' +
    '<a class="btn wa" href="' + esc(waLink(hello)) + '">💬 WhatsApp पर बात करें</a>' +
    '<a class="btn sec" href="https://www.google.com/maps/search/?api=1&query=' + mapQ + '">🗺️ नक्शे में देखें / View Map</a>' +
    '<a class="btn sec" href="https://www.google.com/maps/dir/?api=1&destination=' + mapQ + '">🧭 रास्ता पूछें / Get Directions</a>' +
    '<p class="small">नक्शा Google Maps में खुलेगा (इंटरनेट चाहिए)।</p>';
}

/* ----- Admin ----- */
function viewLogin() {
  V.innerHTML = '<h2>⚙️ एडमिन <small class="small">Admin</small></h2>' +
    '<div class="panel"><label class="f" for="pin">दुकान का PIN डालें / Enter PIN</label>' +
    '<input id="pin" type="password" inputmode="numeric" placeholder="PIN">' +
    '<button class="btn" data-act="login">🔓 अंदर जाएँ</button>' +
    '<p class="small">पहली बार का PIN: <b>1234</b> — अंदर जाकर इसे बदल लें।<br>ध्यान दें: यह PIN सिर्फ़ इस फ़ोन पर ताला है।</p></div>';
}

function viewAdminList() {
  var demoCount = products.filter(function (p) { return p.demo; }).length;
  V.innerHTML = '<h2>⚙️ उत्पाद संभालें <small class="small">Admin</small></h2>' +
    '<button class="btn" data-act="newprod">➕ नया उत्पाद जोड़ें / Add Product</button>' +
    (demoCount ? '<button class="btn sec" data-act="deldemo">🧹 सभी डेमो उत्पाद हटाएँ (' + demoCount + ')</button>' : '') +
    '<div style="height:10px"></div>' +
    (products.length ? products.map(function (p) {
      return '<div class="admin-row"><div class="top"><img alt="" src="' + esc(imgOf(p)) + '"><div style="flex:1;min-width:0">' +
        '<div class="pname">' + esc(p.name) + (p.demo ? ' <span class="tag-demo" style="position:static">डेमो</span>' : '') + '</div>' +
        '<div class="small">' + catOf(p.cat).hi + ' • ' + esc(p.unit || '') + '</div></div></div>' +
        '<div class="qe"><label>दाम ₹ / Price<input type="number" inputmode="decimal" min="0" step="any" data-qf="price" data-id="' + esc(p.id) + '" value="' + p.price + '"></label>' +
        '<label>स्टॉक / Stock<input type="number" inputmode="numeric" min="0" step="1" data-qf="stock" data-id="' + esc(p.id) + '" value="' + p.stock + '"></label></div>' +
        '<div class="acts"><button class="btn sm sec" style="flex:1" data-act="editprod" data-id="' + esc(p.id) + '">✏️ बदलें</button>' +
        '<button class="btn sm red" style="flex:1" data-act="delprod" data-id="' + esc(p.id) + '">🗑️ हटाएँ</button></div></div>';
    }).join('') : '<div class="empty">कोई उत्पाद नहीं। ऊपर "नया उत्पाद जोड़ें" दबाएँ।</div>') +
    '<button class="btn sec" data-act="chpin">🔑 PIN बदलें</button>' +
    '<button class="btn sec" data-act="logout">🚪 एडमिन से बाहर</button>';
}

function viewForm(id) {
  var p = id ? findP(id) : null;
  if (id && !p) { location.hash = '#/admin'; return; }
  ui.form = p ? JSON.parse(JSON.stringify(p)) :
    { id: '', name: '', nameEn: '', cat: 'seeds', price: '', unit: '', stock: '', img: '', demo: false };
  var f = ui.form;
  V.innerHTML = '<h2>' + (p ? '✏️ उत्पाद बदलें' : '➕ नया उत्पाद') + '</h2>' +
    '<label class="f" for="f_name">नाम (हिंदी) / Name *</label><input id="f_name" type="text" value="' + esc(f.name) + '">' +
    '<label class="f" for="f_en">नाम (English, ज़रूरी नहीं)</label><input id="f_en" type="text" value="' + esc(f.nameEn) + '">' +
    '<label class="f" for="f_cat">श्रेणी / Category</label><select id="f_cat">' +
    CATS.map(function (c) { return '<option value="' + c.id + '"' + (c.id === f.cat ? ' selected' : '') + '>' + c.hi + ' / ' + c.en + '</option>'; }).join('') + '</select>' +
    '<label class="f" for="f_price">दाम ₹ / Price *</label><input id="f_price" type="number" inputmode="decimal" min="0" step="any" value="' + esc(f.price) + '">' +
    '<label class="f" for="f_unit">मात्रा / Unit (जैसे: 1 kg, 500 ml)</label><input id="f_unit" type="text" value="' + esc(f.unit) + '">' +
    '<label class="f" for="f_stock">स्टॉक / Stock *</label><input id="f_stock" type="number" inputmode="numeric" min="0" step="1" value="' + esc(f.stock) + '">' +
    '<label class="f">फ़ोटो / Photo</label><img id="f_prev" class="photo-prev" alt="" src="' + esc(imgOf(f)) + '">' +
    '<input id="f_photo" type="file" accept="image/*">' +
    '<button class="btn sm sec" style="margin-top:8px" data-act="rmphoto">फ़ोटो हटाएँ</button>' +
    '<label class="f" style="display:flex;gap:8px;align-items:center"><input id="f_demo" type="checkbox"' + (f.demo ? ' checked' : '') +
    ' style="width:22px;height:22px"> यह डेमो (नमूना) उत्पाद है</label>' +
    '<button class="btn" data-act="saveprod">💾 सेव करें / Save</button>' +
    '<button class="btn sec" data-act="cancelform">रद्द करें</button>';
}

function viewAdmin(sub, id) {
  if (!ui.admin) { viewLogin(); return; }
  if (sub === 'new') { viewForm(null); }
  else if (sub === 'edit') { viewForm(id); }
  else { viewAdminList(); }
}

/* ============ Router ============ */
function route() {
  var h = (location.hash || '#/').replace(/^#\/?/, '');
  var parts = h.split('/');
  var name = parts[0] || 'home';
  ui.form = null;
  if (name === 'cart') { viewCart(); }
  else if (name === 'checkout') { viewCheckout(); }
  else if (name === 'shop') { viewShop(); }
  else if (name === 'admin') { viewAdmin(parts[1], parts[2]); }
  else { name = 'home'; viewHome(); }
  var navName = name === 'checkout' ? 'cart' : name;
  var links = document.querySelectorAll('#nav a');
  for (var i = 0; i < links.length; i++) {
    links[i].className = links[i].getAttribute('data-nav') === navName ? 'active' : '';
  }
  V.scrollTop = 0;
}
window.addEventListener('hashchange', function () { closeModal(); route(); });

function refreshCartViews() {
  var h = location.hash || '#/';
  if (h === '#/' || h === '' || h === '#/home') { renderList(); }
  else { route(); }
}

/* ============ Photo picking (resize so the app stays fast) ============ */
function readImage(file, cb) {
  var fr = new FileReader();
  fr.onload = function () {
    var img = new Image();
    img.onload = function () {
      var max = 480, sc = Math.min(1, max / Math.max(img.width, img.height));
      var c = document.createElement('canvas');
      c.width = Math.max(1, Math.round(img.width * sc));
      c.height = Math.max(1, Math.round(img.height * sc));
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      cb(c.toDataURL('image/jpeg', 0.78));
    };
    img.onerror = function () { cb(null); };
    img.src = fr.result;
  };
  fr.onerror = function () { cb(null); };
  fr.readAsDataURL(file);
}

/* ============ Events ============ */
document.addEventListener('input', function (e) {
  if (e.target && e.target.id === 'q') { ui.q = e.target.value; renderList(); }
});

document.addEventListener('change', function (e) {
  var t = e.target;
  if (!t) { return; }
  if (t.id === 'f_photo' && t.files && t.files[0]) {
    readImage(t.files[0], function (data) {
      if (!data) { toast('फ़ोटो नहीं खुली'); return; }
      ui.form.img = data;
      $('f_prev').src = data;
    });
    return;
  }
  var qf = t.getAttribute && t.getAttribute('data-qf');
  if (qf) {
    var p = findP(t.getAttribute('data-id'));
    var v = parseFloat(t.value);
    if (!p || isNaN(v) || v < 0) { toast('सही संख्या डालें'); t.value = p ? p[qf] : ''; return; }
    p[qf] = qf === 'stock' ? Math.floor(v) : v;
    if (qf === 'stock') { t.value = p.stock; }
    if (saveProducts()) { toast('✅ सेव हो गया'); }
  }
});

document.addEventListener('click', function (e) {
  var el = e.target.closest ? e.target.closest('[data-act]') : null;
  if (!el) { return; }
  var act = el.getAttribute('data-act');
  var id = el.getAttribute('data-id');

  switch (act) {
    case 'cat': ui.cat = el.getAttribute('data-cat'); viewHome(); break;
    case 'add': case 'inc': setQty(id, cartQty(id) + 1); refreshCartViews(); break;
    case 'dec': setQty(id, cartQty(id) - 1); refreshCartViews(); break;
    case 'rm': setQty(id, 0); refreshCartViews(); break;
    case 'clearcart':
      confirmBox('कार्ट पूरा खाली करें?', 'हाँ, खाली करें', function () { cart = []; saveCart(); route(); });
      break;
    case 'modalyes': var fn = modalYes; modalYes = null; closeModal(); if (fn) { fn(); } break;
    case 'modalno': modalYes = null; closeModal(); break;

    case 'sendwa':
      var name = $('c_name').value.trim();
      if (!name) { toast('कृपया अपना नाम लिखें'); $('c_name').focus(); return; }
      if (sanitizeCart()) { toast('कुछ सामान का स्टॉक बदल गया, कार्ट जाँचें'); route(); return; }
      var items = cartItems();
      if (!items.length) { location.hash = '#/cart'; return; }
      customer = { name: name, phone: $('c_phone').value.trim(), addr: $('c_addr').value.trim() };
      store.set('customer', customer);
      var msg = buildMessage({ name: name, phone: customer.phone, addr: customer.addr, note: $('c_note').value.trim() }, items, cartTotal());
      confirmBox('WhatsApp खुल रहा है। ऑर्डर भेजने के बाद क्या कार्ट खाली कर दें?', 'हाँ, कार्ट खाली करें', function () {
        cart = []; saveCart(); location.hash = '#/';
      }, 'नहीं, रहने दें');
      setTimeout(function () { openUrl(waLink(msg)); }, 350);
      break;

    case 'login':
      if ($('pin').value === String(settings.pin)) { ui.admin = true; route(); }
      else { toast('PIN गलत है'); }
      break;
    case 'logout': ui.admin = false; location.hash = '#/'; break;
    case 'newprod': location.hash = '#/admin/new'; break;
    case 'editprod': location.hash = '#/admin/edit/' + id; break;
    case 'cancelform': location.hash = '#/admin'; break;
    case 'rmphoto': ui.form.img = ''; $('f_prev').src = imgOf(ui.form); break;
    case 'saveprod':
      var f = ui.form;
      var nm = $('f_name').value.trim();
      var price = parseFloat($('f_price').value);
      var stock = parseInt($('f_stock').value, 10);
      if (!nm) { toast('नाम लिखें'); return; }
      if (isNaN(price) || price < 0) { toast('सही दाम लिखें'); return; }
      if (isNaN(stock) || stock < 0) { toast('सही स्टॉक लिखें'); return; }
      f.name = nm; f.nameEn = $('f_en').value.trim(); f.cat = $('f_cat').value;
      f.price = price; f.unit = $('f_unit').value.trim(); f.stock = stock; f.demo = $('f_demo').checked;
      if (f.id) {
        for (var i = 0; i < products.length; i++) { if (products[i].id === f.id) { products[i] = f; } }
      } else {
        f.id = 'p' + Date.now();
        products.push(f);
      }
      if (saveProducts()) { sanitizeCart(); toast('✅ उत्पाद सेव हो गया'); location.hash = '#/admin'; }
      break;
    case 'delprod':
      var dp = findP(id);
      if (!dp) { return; }
      confirmBox('"' + esc(dp.name) + '" हमेशा के लिए हटाएँ?', 'हाँ, हटाएँ', function () {
        products = products.filter(function (p) { return p.id !== id; });
        saveProducts(); sanitizeCart(); route(); toast('हटा दिया');
      });
      break;
    case 'deldemo':
      confirmBox('सभी डेमो (नमूना) उत्पाद हटाएँ? आपके अपने जोड़े उत्पाद बने रहेंगे।', 'हाँ, डेमो हटाएँ', function () {
        products = products.filter(function (p) { return !p.demo; });
        saveProducts(); sanitizeCart(); route(); toast('डेमो उत्पाद हटा दिए');
      });
      break;
    case 'chpin':
      modalYes = null;
      showModal('<h3>🔑 नया PIN (4 से 8 अंक)</h3><input id="newpin" type="password" inputmode="numeric" placeholder="नया PIN">' +
        '<button class="btn" data-act="savepin">सेव करें</button><button class="btn sec" data-act="modalno">रद्द करें</button>');
      break;
    case 'savepin':
      var np = $('newpin').value.trim();
      if (!/^[0-9]{4,8}$/.test(np)) { toast('PIN में 4 से 8 अंक होने चाहिए'); return; }
      settings.pin = np; store.set('settings', settings); closeModal(); toast('✅ PIN बदल गया');
      break;
  }
});

/* Android back button support (called from MainActivity) */
window.appBack = function () {
  if (modalOpen()) { closeModal(); return true; }
  var h = location.hash;
  if (h && h !== '#/' && h !== '#' && h !== '#/home') {
    if (history.length > 1) { history.back(); } else { location.hash = '#/'; }
    return true;
  }
  return false;
};

/* For testing */
window.SKK = {
  buildMessage: buildMessage, waLink: waLink,
  get products() { return products; }, get cart() { return cart; }
};

updateBadge();
route();
})();
